
 <h1>Big-Basket Ecommerce</h1>
 
 <h3>Description :</h3>
It is a Grocery website where you can buy day to day grocery for your Household. We tried to implement all the feature I have mentioned below using the tech-Stack I have mentioned below. It is fully functional and responsive website.

<h2>Deployed Link</h2>
https://bigbasket-gold.vercel.app/

<h2>Team Members</h2>
1.Nikhil <br>
2.Vaibhav <br>
3.Prateek <br>
4.Bikram <br>
5.Sammyak <br>
 
 ---

<h3>Tech Stack Used :</h3>
<h5>⚡React</h5>
<h5>⚡React Router</h5>
<h5>⚡Redux</h5>
<h5>⚡Chakra-Ui</h5>
<h5>⚡Axios</h5>
<h5>⚡JavaScript</h5>
<h5>⚡HTML</h5>
<h5>⚡CSS</h5>

---

<h3>Features :</h3>
<h5>✨Home Page with Navbar and Footer</h5>
<h5>✨Authentication</h5>
<h5>✨Filter and sort products by rating and price</h5>
<h5>✨Single Product Page</h5>
<h5>✨Cart page</h5>
<h5>✨Add address details and make payment </h5>

---

<h3>Some Glimps of Project :</h3>
<h5>✨Home Page with Navbar and Footer</h5>
<img src="https://github.com/Nikhil-81/sleek-chance-4491/blob/main/bigbasket/Home.PNG"/>

<h5>✨Login Page</h5>
<img src="https://github.com/Nikhil-81/sleek-chance-4491/blob/main/bigbasket/login%20page.PNG"/>

<h5>✨Products Page</h5>
<img src="https://github.com/Nikhil-81/sleek-chance-4491/blob/main/bigbasket/Product%20Page.PNG"/>

<h5>✨Single Product</h5>
<img src="https://github.com/Nikhil-81/sleek-chance-4491/blob/main/bigbasket/Single%20Product%20Page.PNG"/>

<h5>✨Cart page</h5>
<img src="https://github.com/Nikhil-81/sleek-chance-4491/blob/main/bigbasket/Cart%20Page.PNG"/>

<h5>✨Checkout/Delivery/Address/Payment Page </h5>
<img src="https://github.com/Nikhil-81/sleek-chance-4491/blob/main/bigbasket/Checkout%20Page.PNG"/>
