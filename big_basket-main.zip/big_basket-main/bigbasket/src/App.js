
import './App.css';
import AllRoutes from './All-Routes/AllRoutes';
// import Cart from './Pages/Cart/Cart';
// import Checkout from './Pages/Checkout/Checkout';
// import Navbar from './Components/Navbar/Navbar';
// import Login from './Pages/Login/Login';
// import Home from './Components/Home';


function App() {
  return (
    <div>
  {/* <Cart/> */}
  <AllRoutes/>
    </div>
  );
}

export default App;
