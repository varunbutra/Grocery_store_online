

import "./Home.css";


function Home() {
  return (
   <div>
   
   </div>
  );
}

export default Home;
