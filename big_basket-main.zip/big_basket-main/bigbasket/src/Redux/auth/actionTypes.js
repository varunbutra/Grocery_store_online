export const Login_request="Login_request"
export const Login_error="Login_error"
export const Login_sucess="Login_sucess"


export const Singin_request="Singin_request"
export const Singin_error="Singin_error"
export const Singin_sucess="Singin_sucess"

export const Logout_request="Logout_request"
export const Logout_error="Logout_error"
export const Logout_sucess="Logout_sucess"


